#!/system/bin/sh

# Resolución obligatoria del directorio
MODULE_DIR="$(cd "$(dirname "$0")" && pwd)"

# Registro de estado
STATE="$MODULE_DIR/.state_ff"

FF_PKG="com.dts.freefireth"

# Guardar estado solo una vez
if [ ! -f "$STATE" ]; then
    echo "saving_state" > "$STATE"
fi

# ❌ Desactivar ahorro de energía
settings put global low_power 0
settings put global adaptive_battery_management_enabled 0
settings put global app_standby_enabled 0

# 🔥 CPU al máximo
for gov in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do
    echo performance > "$gov" 2>/dev/null
done

# 🚀 GPU al máximo (Qualcomm)
if [ -e /sys/class/kgsl/kgsl-3d0/devfreq/governor ]; then
    echo performance > /sys/class/kgsl/kgsl-3d0/devfreq/governor
fi

# 🧠 Scheduler agresivo
echo 0 > /proc/sys/kernel/sched_autogroup_enabled 2>/dev/null
echo 1 > /proc/sys/kernel/sched_child_runs_first 2>/dev/null

# 🧹 Limpieza agresiva de RAM
sync
echo 3 > /proc/sys/vm/drop_caches

# 🌡️ Intentar desactivar thermal throttling
stop thermal-engine 2>/dev/null
stop vendor.thermal-engine 2>/dev/null

# 🎮 Prioridad máxima para Free Fire (si está abierto)
PID=$(pidof $FF_PKG)
if [ -n "$PID" ]; then
    renice -20 -p $PID
fi
