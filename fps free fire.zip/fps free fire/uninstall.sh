#!/system/bin/sh

MODULE_DIR="$(cd "$(dirname "$0")" && pwd)"
STATE="$MODULE_DIR/.state_ff"

# Restaurar governors CPU
for gov in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do
    echo schedutil > "$gov" 2>/dev/null || echo ondemand > "$gov" 2>/dev/null
done

# Restaurar GPU
if [ -e /sys/class/kgsl/kgsl-3d0/devfreq/governor ]; then
    echo msm-adreno-tz > /sys/class/kgsl/kgsl-3d0/devfreq/governor
fi

# Restaurar scheduler
echo 1 > /proc/sys/kernel/sched_autogroup_enabled 2>/dev/null

# Reactivar thermal
start thermal-engine 2>/dev/null
start vendor.thermal-engine 2>/dev/null

# Limpiar estado
[ -f "$STATE" ] && rm -f "$STATE"
