#!/system/bin/sh

#This is an example shell script.
#Use the file manager or the top left menu to create new shell scripts.

echo "   _____           _   
  / ____|         | |  
 | |  __  ___  ___| |_ 
 | | |_ |/ _ \/ __| __|
 | |__| |  __/\__ \ |_ 
  \_____|\___||___/\__|
                       
                       "

sleep 1

echo "Modelo del teléfono: $(getprop ro.product.model)"
echo "Versión de Android: $(getprop ro.build.version.release)"
echo "SDK: $(getprop ro.build.version.sdk)"

echo "configurando gestos latersles"

settings put secure back_gesture_inset_scale_left -1
settings put secure back_gesture_inset_scale_right -1
settings put secure back_gesture_inset_left -1
settings put secure back_gesture_inset_right -1

echo "ok"
clear
