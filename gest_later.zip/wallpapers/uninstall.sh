#!/system/bin/sh

echo "   _____           _   
  / ____|         | |  
 | |  __  ___  ___| |_ 
 | | |_ |/ _ \/ __| __|
 | |__| |  __/\__ \ |_ 
  \_____|\___||___/\__|
                       
                       "


sleep 1

echo "Modelo del teléfono: $(getprop ro.product.model)"
echo "Versión de Android: $(getprop ro.build.version.release)"
echo "SDK: $(getprop ro.build.version.sdk)"

echo "restaurando configuracion de gestos laterales"

settings delete secure back_gesture_inset_scale_left
settings delete secure back_gesture_inset_scale_right
settings delete secure back_gesture_inset_left
settings delete secure back_gesture_inset_right

echo "gestos restaurados"
clear
